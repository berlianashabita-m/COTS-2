<?php
// Create SQLite DB and tables, seed data
$dbfile = __DIR__ . '/data/database.sqlite';
@mkdir(__DIR__.'/data', 0777, true);
if (file_exists($dbfile)) {
    echo "Database already exists at $dbfile\n";
    exit;
}
$pdo = new PDO('sqlite:'. $dbfile);
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

$pdo->exec("CREATE TABLE users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE,
    password TEXT,
    role TEXT
)");

$pdo->exec("CREATE TABLE categories (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT UNIQUE NOT NULL
)");

$pdo->exec("CREATE TABLE products (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    price REAL DEFAULT 0,
    stock INTEGER DEFAULT 0,
    description TEXT,
    category_id INTEGER,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(category_id) REFERENCES categories(id)
)");

// Seed users (passwords stored in plaintext for demo only)
$pdo->prepare('INSERT INTO users (username,password,role) VALUES (?,?,?)')->execute(['admin','admin123','admin']);
$pdo->prepare('INSERT INTO users (username,password,role) VALUES (?,?,?)')->execute(['user','user123','user']);

// Seed categories
$pdo->prepare('INSERT INTO categories (name) VALUES (?)')->execute(['Stationery']);
$pdo->prepare('INSERT INTO categories (name) VALUES (?)')->execute(['Snack']);

// Seed products
$pdo->prepare('INSERT INTO products (name,price,stock,description,category_id) VALUES (?,?,?,?,?)')
    ->execute(['Pens', 1500, 20, 'Blue ballpoint pens', 1]);
$pdo->prepare('INSERT INTO products (name,price,stock,description,category_id) VALUES (?,?,?,?,?)')
    ->execute(['Chips', 5000, 50, 'Crunchy chips', 2]);

echo "Database initialized at $dbfile\n";
