Project: COTS - Web App (PHP, SQLite)
Run locally (from terminal):
1. php init_db.php    # create sqlite DB and seed sample data
2. php -S localhost:8000
3. Open http://localhost:8000 in browser

Features:
- Auth (hardcoded users: admin/admin123 and user/user123) using PHP session
- Middleware to protect /admin routes (role=admin)
- Product CRUD with validation (name unique, min length, price numeric >=0, stock integer >=0)
- Category CRUD and product relation (product.category_id)
- Search products by name (?q=...)
