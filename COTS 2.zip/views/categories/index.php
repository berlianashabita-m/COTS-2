<div class="d-flex justify-content-between align-items-center mb-3">
  <h2>Categories</h2>
  <a href="/categories/create" class="btn btn-success">Create Category</a>
</div>
<ul class="list-group">
<?php foreach($categories as $c): ?>
  <li class="list-group-item d-flex justify-content-between align-items-center">
    <a href="/categories/<?php echo $c['id']; ?>/products"><?php echo htmlspecialchars($c['name']); ?></a>
    <span class="badge bg-secondary rounded-pill"></span>
  </li>
<?php endforeach; ?>
</ul>
