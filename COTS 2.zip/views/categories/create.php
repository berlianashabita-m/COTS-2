<h2>Create Category</h2>
<form method="POST" action="/categories/create">
  <div class="mb-3"><input name="name" class="form-control" placeholder="Category name"></div>
  <button class="btn btn-primary" type="submit">Save</button>
</form>
