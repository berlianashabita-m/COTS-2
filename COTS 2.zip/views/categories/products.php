<h2>Products in <?php echo htmlspecialchars($category['name']); ?></h2>
<a href="/products/create" class="btn btn-sm btn-success mb-2">Create Product</a>
<table class="table"><thead><tr><th>Name</th><th>Price</th><th>Stock</th></tr></thead><tbody>
<?php foreach($products as $p): ?>
  <tr>
    <td><?php echo htmlspecialchars($p['name']); ?></td>
    <td><?php echo number_format($p['price'],0); ?></td>
    <td><?php echo $p['stock']; ?></td>
  </tr>
<?php endforeach; ?>
</tbody></table>
