<div class="row justify-content-center">
  <div class="col-md-6">
    <h2>Login</h2>
    <form method="POST" action="/login">
      <div class="mb-3"><input name="username" class="form-control" placeholder="username"></div>
      <div class="mb-3"><input type="password" name="password" class="form-control" placeholder="password"></div>
      <button class="btn btn-primary" type="submit">Login</button>
    </form>
    <p class="mt-3">Demo accounts: admin/admin123 and user/user123</p>
  </div>
</div>
