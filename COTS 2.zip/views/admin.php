<h2>Admin Page</h2>
<p>Accessible only for users with role=admin</p>
