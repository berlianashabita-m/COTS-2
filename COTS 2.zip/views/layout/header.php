<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title><?php echo $title ?? 'COTS App'; ?></title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-light bg-light mb-4">
  <div class="container">
    <a class="navbar-brand" href="/">COTS</a>
    <div class="collapse navbar-collapse">
      <ul class="navbar-nav me-auto">
        <li class="nav-item"><a class="nav-link" href="/products">Products</a></li>
        <li class="nav-item"><a class="nav-link" href="/categories">Categories</a></li>
        <li class="nav-item"><a class="nav-link" href="/admin">Admin</a></li>
      </ul>
      <form class="d-flex" method="GET" action="/products">
        <input class="form-control me-2" name="q" placeholder="Search" value="<?php echo htmlspecialchars($q ?? ''); ?>">
        <button class="btn btn-outline-success" type="submit">Search</button>
      </form>
      <ul class="navbar-nav ms-3">
        <?php if(isset($_SESSION['user'])): ?>
          <li class="nav-item"><span class="nav-link">Hi, <?php echo htmlspecialchars($_SESSION['user']['username']); ?></span></li>
          <li class="nav-item"><a class="nav-link" href="/logout">Logout</a></li>
        <?php else: ?>
          <li class="nav-item"><a class="nav-link" href="/login">Login</a></li>
        <?php endif; ?>
      </ul>
    </div>
  </div>
</nav>
<div class="container">
<?php if($msg = flash()): ?>
  <div class="alert alert-info"><?php echo htmlspecialchars($msg); ?></div>
<?php endif; ?>
