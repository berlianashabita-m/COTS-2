<h2>Create Product</h2>
<form method="POST" action="/products/create">
  <div class="mb-3"><input name="name" class="form-control" placeholder="Name" value="<?php echo htmlspecialchars(old('name')); ?>"></div>
  <div class="mb-3"><input name="price" class="form-control" placeholder="Price" value="<?php echo htmlspecialchars(old('price')); ?>"></div>
  <div class="mb-3"><input name="stock" class="form-control" placeholder="Stock" value="<?php echo htmlspecialchars(old('stock')); ?>"></div>
  <div class="mb-3">
    <select name="category_id" class="form-select">
      <option value=''>-- Select Category (optional) --</option>
      <?php foreach($categories as $c): ?>
        <option value="<?php echo $c['id']; ?>"><?php echo htmlspecialchars($c['name']); ?></option>
      <?php endforeach; ?>
    </select>
  </div>
  <div class="mb-3"><textarea name="description" class="form-control" placeholder="Description"><?php echo htmlspecialchars(old('description')); ?></textarea></div>
  <button class="btn btn-primary" type="submit">Save</button>
</form>
