<h2>Edit Product</h2>
<form method="POST" action="/products/<?php echo $product['id']; ?>/edit">
  <div class="mb-3"><input name="name" class="form-control" placeholder="Name" value="<?php echo htmlspecialchars($product['name']); ?>"></div>
  <div class="mb-3"><input name="price" class="form-control" placeholder="Price" value="<?php echo htmlspecialchars($product['price']); ?>"></div>
  <div class="mb-3"><input name="stock" class="form-control" placeholder="Stock" value="<?php echo htmlspecialchars($product['stock']); ?>"></div>
  <div class="mb-3">
    <select name="category_id" class="form-select">
      <option value=''>-- Select Category (optional) --</option>
      <?php foreach($categories as $c): ?>
        <option value="<?php echo $c['id']; ?>" <?php echo ($product['category_id']==$c['id'])?'selected':''; ?>><?php echo htmlspecialchars($c['name']); ?></option>
      <?php endforeach; ?>
    </select>
  </div>
  <div class="mb-3"><textarea name="description" class="form-control" placeholder="Description"><?php echo htmlspecialchars($product['description']); ?></textarea></div>
  <button class="btn btn-primary" type="submit">Update</button>
</form>
