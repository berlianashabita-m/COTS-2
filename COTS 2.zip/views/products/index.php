<div class="d-flex justify-content-between align-items-center mb-3">
  <h2>Products</h2>
  <a href="/products/create" class="btn btn-success">Create</a>
</div>
<table class="table table-striped">
  <thead><tr><th>Name</th><th>Category</th><th>Price</th><th>Stock</th><th>Actions</th></tr></thead>
  <tbody>
  <?php foreach($products as $p): ?>
    <tr>
      <td><?php echo htmlspecialchars($p['name']); ?></td>
      <td><?php echo htmlspecialchars($p['category_name'] ?? '-'); ?></td>
      <td><?php echo number_format($p['price'],0); ?></td>
      <td><?php echo $p['stock']; ?></td>
      <td>
        <a href="/products/<?php echo $p['id']; ?>/edit" class="btn btn-sm btn-primary">Edit</a>
        <form method="POST" action="/products/<?php echo $p['id']; ?>/delete" style="display:inline" onsubmit="return confirm('Delete?')">
          <button class="btn btn-sm btn-danger">Delete</button>
        </form>
      </td>
    </tr>
  <?php endforeach; ?>
  </tbody>
</table>
