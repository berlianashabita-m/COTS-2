<?php
$dbfile = __DIR__.'/../data/database.sqlite';
if (!file_exists($dbfile)) {
    http_response_code(500);
    echo 'Database not initialized. Run php init_db.php';
    exit;
}
$pdo = new PDO('sqlite:'.$dbfile);
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
