<?php
function ensureRole($role) {
    if (!isset($_SESSION['user'])) {
        header('Location: /login');
        exit;
    }
    if ($_SESSION['user']['role'] !== $role) {
        echo '403 - Forbidden (requires role: ' . $role . ')';
        exit;
    }
}
