<?php
function view($path, $data = []) {
    extract($data);
    include __DIR__ . '/../views/layout/header.php';
    include __DIR__ . '/../views/' . $path;
    include __DIR__ . '/../views/layout/footer.php';
}

function render($file, $data = []) {
    extract($data);
    include __DIR__ . '/../views/layout/header.php';
    include __DIR__ . '/../views/' . $file;
    include __DIR__ . '/../views/layout/footer.php';
}

function old($key) {
    return $_POST[$key] ?? '';
}

function flash() {
    if (isset($_SESSION['flash'])) {
        $t = $_SESSION['flash'];
        unset($_SESSION['flash']);
        return $t;
    }
    return null;
}
