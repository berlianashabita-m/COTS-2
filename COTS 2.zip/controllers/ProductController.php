<?php
class ProductController {
    private $pdo;
    public function __construct($pdo){ $this->pdo = $pdo; }
    public function index() {
        $q = $_GET['q'] ?? '';
        if ($q) {
            $stmt = $this->pdo->prepare('SELECT p.*, c.name as category_name FROM products p LEFT JOIN categories c ON p.category_id=c.id WHERE p.name LIKE ? ORDER BY p.created_at DESC');
            $stmt->execute(['%'.$q.'%']);
        } else {
            $stmt = $this->pdo->query('SELECT p.*, c.name as category_name FROM products p LEFT JOIN categories c ON p.category_id=c.id ORDER BY p.created_at DESC');
        }
        $products = $stmt->fetchAll(PDO::FETCH_ASSOC);
        view('products/index.php', ['title'=>'Products','products'=>$products,'q'=>$q]);
    }
    public function create() {
        $cats = $this->pdo->query('SELECT * FROM categories')->fetchAll(PDO::FETCH_ASSOC);
        view('products/create.php', ['title'=>'Create Product','categories'=>$cats]);
    }
    public function store() {
        $name = trim($_POST['name'] ?? '');
        $price = $_POST['price'] ?? 0;
        $stock = $_POST['stock'] ?? 0;
        $desc = $_POST['description'] ?? '';
        $category_id = $_POST['category_id'] ?: null;

        // validations
        $errors = [];
        if (!$name || strlen($name) < 3) $errors[] = 'name min 3 chars';
        // unique name
        $stmt = $this->pdo->prepare('SELECT COUNT(*) FROM products WHERE name = ?');
        $stmt->execute([$name]);
        if ($stmt->fetchColumn() > 0) $errors[] = 'name must be unique';
        if (!is_numeric($price) || $price < 0) $errors[] = 'price numeric >=0';
        if (!ctype_digit((string)$stock) || (int)$stock < 0) $errors[] = 'stock integer >=0';

        if ($errors) {
            $_SESSION['flash'] = implode('; ', $errors);
            header('Location: /products/create'); exit;
        }

        $stmt = $this->pdo->prepare('INSERT INTO products (name,price,stock,description,category_id) VALUES (?,?,?,?,?)');
        $stmt->execute([$name,$price,$stock,$desc,$category_id]);
        $_SESSION['flash'] = 'Product created';
        header('Location: /products'); exit;
    }
    public function edit($id) {
        $stmt = $this->pdo->prepare('SELECT * FROM products WHERE id=?');
        $stmt->execute([$id]); $product = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$product) { echo 'Not found'; exit; }
        $cats = $this->pdo->query('SELECT * FROM categories')->fetchAll(PDO::FETCH_ASSOC);
        view('products/edit.php', ['title'=>'Edit Product','product'=>$product,'categories'=>$cats]);
    }
    public function update($id) {
        $name = trim($_POST['name'] ?? '');
        $price = $_POST['price'] ?? 0;
        $stock = $_POST['stock'] ?? 0;
        $desc = $_POST['description'] ?? '';
        $category_id = $_POST['category_id'] ?: null;
        $errors = [];
        if (!$name || strlen($name) < 3) $errors[] = 'name min 3 chars';
        // unique except self
        $stmt = $this->pdo->prepare('SELECT COUNT(*) FROM products WHERE name = ? AND id != ?');
        $stmt->execute([$name,$id]);
        if ($stmt->fetchColumn() > 0) $errors[] = 'name must be unique';
        if (!is_numeric($price) || $price < 0) $errors[] = 'price numeric >=0';
        if (!ctype_digit((string)$stock) || (int)$stock < 0) $errors[] = 'stock integer >=0';
        if ($errors) {
            $_SESSION['flash'] = implode('; ', $errors);
            header('Location: /products/'.$id.'/edit'); exit;
        }
        $stmt = $this->pdo->prepare('UPDATE products SET name=?,price=?,stock=?,description=?,category_id=? WHERE id=?');
        $stmt->execute([$name,$price,$stock,$desc,$category_id,$id]);
        $_SESSION['flash'] = 'Product updated';
        header('Location: /products'); exit;
    }
    public function destroy($id) {
        $stmt = $this->pdo->prepare('DELETE FROM products WHERE id=?');
        $stmt->execute([$id]);
        $_SESSION['flash'] = 'Product deleted';
        header('Location: /products'); exit;
    }
}
