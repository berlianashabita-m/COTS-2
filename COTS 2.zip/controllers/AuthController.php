<?php
class AuthController {
    private $pdo;
    public function __construct($pdo) { $this->pdo = $pdo; }
    public function showLogin() {
        view('auth/login.php', ['title'=>'Login']);
    }
    public function login() {
        $username = $_POST['username'] ?? '';
        $password = $_POST['password'] ?? '';
        if (!$username || !$password) {
            $_SESSION['flash'] = 'username and password required';
            header('Location: /login'); exit;
        }
        $stmt = $this->pdo->prepare('SELECT id,username,role FROM users WHERE username=? AND password=?');
        $stmt->execute([$username,$password]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);
        if ($user) {
            $_SESSION['user'] = $user;
            header('Location: /'); exit;
        } else {
            $_SESSION['flash'] = 'Invalid credentials';
            header('Location: /login'); exit;
        }
    }
    public function logout() {
        session_destroy();
        header('Location: /login'); exit;
    }
}
