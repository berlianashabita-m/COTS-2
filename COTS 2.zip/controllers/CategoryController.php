<?php
class CategoryController {
    private $pdo;
    public function __construct($pdo){ $this->pdo = $pdo; }
    public function index() {
        $cats = $this->pdo->query('SELECT * FROM categories ORDER BY name')->fetchAll(PDO::FETCH_ASSOC);
        view('categories/index.php', ['title'=>'Categories','categories'=>$cats]);
    }
    public function create() {
        view('categories/create.php', ['title'=>'Create Category']);
    }
    public function store() {
        $name = trim($_POST['name'] ?? '');
        if (!$name) { $_SESSION['flash']='Name required'; header('Location: /categories/create'); exit; }
        $stmt = $this->pdo->prepare('INSERT INTO categories (name) VALUES (?)');
        try {
            $stmt->execute([$name]);
        } catch (Exception $e) {
            $_SESSION['flash']='Name must be unique';
            header('Location: /categories/create'); exit;
        }
        $_SESSION['flash']='Category created';
        header('Location: /categories'); exit;
    }
    public function products($category_id) {
        $stmt = $this->pdo->prepare('SELECT * FROM categories WHERE id=?');
        $stmt->execute([$category_id]); $cat = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$cat) { echo 'Category not found'; exit; }
        $stmt = $this->pdo->prepare('SELECT * FROM products WHERE category_id = ? ORDER BY created_at DESC');
        $stmt->execute([$category_id]); $products = $stmt->fetchAll(PDO::FETCH_ASSOC);
        view('categories/products.php', ['title'=>'Products in '.$cat['name'],'category'=>$cat,'products'=>$products]);
    }
}
