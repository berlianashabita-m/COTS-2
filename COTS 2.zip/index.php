<?php
session_start();
require_once __DIR__.'/lib/helpers.php';
require_once __DIR__.'/lib/db.php';
// Simple router
$uri = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
$method = $_SERVER['REQUEST_METHOD'];

// Routes mapping
if ($uri === '/' || $uri === '/products') {
    require __DIR__.'/controllers/ProductController.php';
    $ctrl = new ProductController($pdo);
    if ($method === 'GET') $ctrl->index();
} elseif ($uri === '/products/create') {
    require __DIR__.'/controllers/ProductController.php';
    $ctrl = new ProductController($pdo);
    if ($method === 'GET') $ctrl->create();
    if ($method === 'POST') $ctrl->store();
} elseif (preg_match('#^/products/([0-9]+)/edit$#', $uri, $m)) {
    require __DIR__.'/controllers/ProductController.php';
    $ctrl = new ProductController($pdo);
    if ($method === 'GET') $ctrl->edit($m[1]);
    if ($method === 'POST') $ctrl->update($m[1]);
} elseif (preg_match('#^/products/([0-9]+)/delete$#', $uri, $m)) {
    require __DIR__.'/controllers/ProductController.php';
    $ctrl = new ProductController($pdo);
    if ($method === 'POST') $ctrl->destroy($m[1]);
} elseif ($uri === '/categories') {
    require __DIR__.'/controllers/CategoryController.php';
    $ctrl = new CategoryController($pdo);
    if ($method === 'GET') $ctrl->index();
} elseif ($uri === '/categories/create') {
    require __DIR__.'/controllers/CategoryController.php';
    $ctrl = new CategoryController($pdo);
    if ($method === 'GET') $ctrl->create();
    if ($method === 'POST') $ctrl->store();
} elseif (preg_match('#^/categories/([0-9]+)/products$#', $uri, $m)) {
    require __DIR__.'/controllers/CategoryController.php';
    $ctrl = new CategoryController($pdo);
    if ($method === 'GET') $ctrl->products($m[1]);
} elseif ($uri === '/login') {
    require __DIR__.'/controllers/AuthController.php';
    $ctrl = new AuthController($pdo);
    if ($method === 'GET') $ctrl->showLogin();
    if ($method === 'POST') $ctrl->login();
} elseif ($uri === '/logout') {
    require __DIR__.'/controllers/AuthController.php';
    $ctrl = new AuthController($pdo);
    $ctrl->logout();
} elseif ($uri === '/admin') {
    // middleware ensure role=admin
    require __DIR__.'/lib/middleware.php';
    ensureRole('admin');
    // simple admin page
    render('admin.php', ['title'=>'Admin Page']);
} else {
    http_response_code(404);
    echo '404 Not Found';
}
